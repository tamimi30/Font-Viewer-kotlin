import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
    id("org.openrewrite.rewrite") version "7.39.0"
}

rewrite {
    activeRecipe(
        "org.openrewrite.staticanalysis.CommonStaticAnalysis",
        "org.openrewrite.java.RemoveUnusedImports",
        "org.openrewrite.staticanalysis.RemoveUnusedPrivateMethods",
        "org.openrewrite.staticanalysis.RemoveUnusedPrivateFields"
    )

    failOnDryRunResults = false
    sizeThresholdMb = 10
}

android {
    namespace = "com.oneui.fontviewer"
    compileSdk = 36

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "com.oneui.fontviewer"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
        resourceConfigurations += listOf("en", "ar")

        missingDimensionStrategy("version", "release")

        // هل يعتبر التحقق من التحديث إصدارات GitHub المعلّمة كـ pre-release تحديثاً؟
        // true أثناء التجربة (نرفع نسخة تجريبية على GitHub كـ pre-release ونختبر ظهور التحديث).
        // اجعلها false عند النشر الرسمي كي لا يُعرض على المستخدمين إلا الإصدارات المستقرة.
        buildConfigField("boolean", "UPDATE_INCLUDE_PRERELEASES", "true")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            buildConfigField("boolean", "ENABLE_CRASH_LOGGING", "true")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    packaging {
        resources {
            excludes += listOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt",
                "META-INF/*.kotlin_module"
            )
        }
    }
}

// كان في ملف Groovy داخل android { } ويُحَلّ إلى إضافة kotlin الخاصة بالمشروع.
// في Kotlin DSL نضعه على مستوى المشروع ليكون الحل صريحاً.
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_21)
    }
}

configurations.all {
    exclude(group = "androidx.appcompat", module = "appcompat")
    exclude(group = "androidx.core", module = "core")
    exclude(group = "androidx.coordinatorlayout", module = "coordinatorlayout")
    exclude(group = "androidx.drawerlayout", module = "drawerlayout")
    exclude(group = "androidx.recyclerview", module = "recyclerview")
    exclude(group = "androidx.fragment", module = "fragment")
    exclude(group = "androidx.preference", module = "preference")

    resolutionStrategy {
        force("org.jetbrains.kotlin:kotlin-stdlib:2.4.21")
        force("androidx.annotation:annotation:1.11.0")
        force("com.google.guava:guava:33.7.2-jre")
    }
}

dependencies {
    rewrite(platform("org.openrewrite:rewrite-bom:8.90.4"))
    rewrite("org.openrewrite:rewrite-java")
    rewrite("org.openrewrite:rewrite-xml")
    rewrite("org.openrewrite:rewrite-gradle")
    rewrite("org.openrewrite.recipe:rewrite-static-analysis:2.41.1")
    rewrite("org.openrewrite.recipe:rewrite-java-dependencies:1.60.2")

    implementation("io.github.oneuiproject.sesl:appcompat:1.4.0")
    implementation("io.github.oneuiproject.sesl:material:1.5.0")
    implementation("io.github.oneuiproject.sesl:coordinatorlayout:1.0.0")
    implementation("io.github.oneuiproject.sesl:drawerlayout:1.0.0")
    implementation("io.github.oneuiproject.sesl:recyclerview:1.4.1")
    implementation("io.github.oneuiproject.sesl:preference:1.1.0")
    implementation("io.github.oneuiproject.sesl:fragment:1.0.0")

    implementation("io.github.oneuiproject:design:1.2.6")

    implementation("io.github.oneuiproject:icons:1.1.0")
    implementation("com.airbnb.android:lottie:6.7.1")

    // Lifecycle Components
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.11.1")
    implementation("androidx.lifecycle:lifecycle-livedata:2.11.1")
    implementation("androidx.lifecycle:lifecycle-runtime:2.11.1")
    implementation("androidx.lifecycle:lifecycle-common-java8:2.11.1")

    // Kotlin Coroutines (بديل RxJava)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.11.0")

    // Room Database
    implementation("androidx.room:room-runtime:2.8.5")
    ksp("androidx.room:room-compiler:2.8.5")

    // DataStore Preferences
    implementation("androidx.datastore:datastore-preferences:1.3.0")

    implementation("androidx.annotation:annotation:1.11.0")
    implementation("androidx.documentfile:documentfile:1.1.0")
    implementation("androidx.core:core-splashscreen:1.2.0")

    // Google Play In-App Updates: يُستخدم فقط لمعرفة توفر تحديث للنسخة المثبتة من Play Store
    implementation("com.google.android.play:app-update:2.1.0")

    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.7.0")
}
