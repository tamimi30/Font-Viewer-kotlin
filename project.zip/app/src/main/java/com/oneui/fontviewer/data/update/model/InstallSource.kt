package com.oneui.fontviewer.data.update.model

/** المصدر الذي ثُبّتت منه النسخة الحالية من التطبيق، وهو يحدد وجهة زر التحديث. */
enum class InstallSource {
    GOOGLE_PLAY,
    GALAXY_STORE,
    /** أي تثبيت يدوي (ملف APK من GitHub أو غيره). */
    GITHUB
}
